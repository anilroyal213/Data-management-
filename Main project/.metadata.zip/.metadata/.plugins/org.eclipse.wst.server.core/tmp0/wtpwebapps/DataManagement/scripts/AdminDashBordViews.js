$(document).ready(function (){
    $("#viewUsers").on("click",function(){
        $.ajax({
            url : "",
            type : "GET",
            success : function(){

            },
            error : function(){

            }
        })
    });
    $("#viewUploadedData").on("click",function(){
        $.ajax({
            url : "",
            type : "GET",
            success : function(){

            },
            error : function(){
                
            }
        })

    });
    $("#viewHistory").on("click",function(){
        $.ajax({
            url : "",
            type : "GET",
            success : function(){

            },
            error : function(){
                
            }
        })

    });
    $("#uploadData").on("click",function(){

    });
});