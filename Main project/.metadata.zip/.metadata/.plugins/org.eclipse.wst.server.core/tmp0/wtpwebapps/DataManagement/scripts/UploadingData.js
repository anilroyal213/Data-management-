$(document).ready(function(){
    $("#submitButton").on("click",function(e){
        e.preventDefault();
        const formData = new FormData();
        console.log($("#file"))
        console.log($("#file").files[0]);
        formData.append('file',$("#file").files[0]);
        $.ajax({
            url : "",
            type : 'POST',
            data : formData,
            processData : false,
            contentType : false,
            success : function(response){
                console.log("Response from server:" + response)
            },
            error : function(xhr, status, error){
                console.log("Error:" + error);
            }
        })
    })
});